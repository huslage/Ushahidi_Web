=== About ===
name: Mobile Edition
website: http://www.ushahidi.com
description: Mobile Accessible Version of Ushahidi
version: 0.9.4
requires: 2.0
tested up to: 2.0
author: David Kobia
author website: http://www.dkfactor.com

== Description ==

== Installation ==
1. Copy the entire /mobile/ directory into your /plugins/ directory.
2. Activate the plugin.

== Changelog ==
0.9.4
- More fixes to prevent API call inteference

0.9.2
- Mobile hook interfered with api calls

0.9.1
- Modified to work with the latest version of 2.0