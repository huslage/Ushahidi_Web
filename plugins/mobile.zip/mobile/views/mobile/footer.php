		</div>
		<div id="footer">
			&nbsp;&nbsp;<a href="<?php echo url::site() ?>?full=1">View Full Website</a>&nbsp;|&nbsp;Powered By <a href="http://www.ushahidi.com">Ushahidi.com</a>
		</div>
	</div>
	<?php echo $google_analytics; ?>
</body>
</html>